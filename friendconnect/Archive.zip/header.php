<!--This header page is used on pages that don't require authentication-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>FriendConnect.com</title>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="//d79i1fxsrar4t.cloudfront.net/jquery.liveaddress/2.4/jquery.liveaddress.min.js"></script>
        <script>jQuery.extend(Drupal.settings, {"basePath":"\u002F", "pathPrefix":"", "ajaxPageState":{"theme":"redroute", "theme_token":"nGP1MV5dMJl3QqMZy6z5Erer_Hn-l2xeBaPvjM1YiHU", "js":{"misc\u002Fjquery.js":1, "misc\u002Fjquery.once.js":1, "misc\u002Fdrupal.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fadmin_menu\u002Fadmin_devel\u002Fadmin_devel.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Flightbox2\u002Fjs\u002Flightbox.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fviews_slideshow\u002Fjs\u002Fviews_slideshow.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fextlink\u002Fextlink.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fgoogle_analytics\u002Fgoogleanalytics.js":1, "0":1, "misc\u002Ftableheader.js":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fdisqus\u002Fdisqus.js":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fjs\u002Fjquery.cycle.lite.js":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fjs\u002Fjquery.scrollTo-1.4.3-min.js":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fjs\u002Fscript.js":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fprism\u002Fprism.js":1}, "css":{"modules\u002Fsystem\u002Fsystem.base.css":1, "modules\u002Fsystem\u002Fsystem.menus.css":1, "modules\u002Fsystem\u002Fsystem.messages.css":1, "modules\u002Fsystem\u002Fsystem.theme.css":1, "modules\u002Fbook\u002Fbook.css":1, "modules\u002Ffield\u002Ftheme\u002Ffield.css":1, "modules\u002Fnode\u002Fnode.css":1, "modules\u002Fsearch\u002Fsearch.css":1, "modules\u002Fuser\u002Fuser.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fviews\u002Fcss\u002Fviews.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fcodefilter\u002Fcodefilter.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fctools\u002Fcss\u002Fctools.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fflickr\u002Fflickr.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Flightbox2\u002Fcss\u002Flightbox.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Ftagadelic\u002Ftagadelic.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fviews_slideshow\u002Fviews_slideshow.css":1, "sites\u002Fall\u002Fmodules\u002Fcontrib\u002Fextlink\u002Fextlink.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fsystem.menus.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fnormalize.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fwireframes.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Flayouts\u002Fresponsive-sidebars.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fpage-backgrounds.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Ftabs.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fpages.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fblocks.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fnavigation.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fviews-styles.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fnodes.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fcomments.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fforms.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Ffields.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fprism\u002Fprism.css":1, "sites\u002Fall\u002Fthemes\u002Fredroute\u002Fcss\u002Fprint.css":1}}, "lightbox2":{"rtl":0, "file_path":"\u002F(\u005Cw\u005Cw\u002F)public:\u002F", "default_image":"\u002Fsites\u002Fall\u002Fmodules\u002Fcontrib\u002Flightbox2\u002Fimages\u002Fbrokenimage.jpg", "border_size":10, "font_color":"000", "box_color":"fff", "top_position":"", "overlay_opacity":"0.8", "overlay_color":"000", "disable_close_click":1, "resize_sequence":0, "resize_speed":400, "fade_in_speed":400, "slide_down_speed":600, "use_alt_layout":0, "disable_resize":0, "disable_zoom":0, "force_show_nav":0, "show_caption":1, "loop_items":1, "node_link_text":"", "node_link_target":0, "image_count":"Image !current of !total", "video_count":"Video !current of !total", "page_count":"Page !current of !total", "lite_press_x_close":"press \u003Ca href=\u0022#\u0022 onclick=\u0022hideLightbox(); return FALSE;\u0022\u003E\u003Ckbd\u003Ex\u003C\u002Fkbd\u003E\u003C\u002Fa\u003E to close", "download_link_text":"", "enable_login":false, "enable_contact":false, "keys_close":"c x 27", "keys_previous":"p 37", "keys_next":"n 39", "keys_zoom":"z", "keys_play_pause":"32", "display_image_size":"original", "image_node_sizes":"()", "trigger_lightbox_classes":"", "trigger_lightbox_group_classes":"", "trigger_slideshow_classes":"", "trigger_lightframe_classes":"", "trigger_lightframe_group_classes":"", "custom_class_handler":0, "custom_trigger_classes":"", "disable_for_gallery_lists":true, "disable_for_acidfree_gallery_lists":true, "enable_acidfree_videos":true, "slideshow_interval":5000, "slideshow_automatic_start":true, "slideshow_automatic_exit":true, "show_play_pause":true, "pause_on_next_click":false, "pause_on_previous_click":true, "loop_slides":false, "iframe_width":600, "iframe_height":400, "iframe_border":1, "enable_video":0}, "extlink":{"extTarget":"_blank", "extClass":"ext", "extSubdomains":1, "extExclude":"", "extInclude":"", "extAlert":0, "extAlertText":"This link will take you to an external web site. We are not responsible for their content.", "mailtoClass":"mailto"}, "googleanalytics":{"trackOutbound":1, "trackMailto":1, "trackDownload":1, "trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls|xml|z|zip"}, "disqus":{"domain":"redroute", "url":"http:\u002F\u002Fred-route.org\u002Fcode\u002Fqr-code-generation-using-google-api", "title":"QR code generation using the Google API", "identifier":"node\u002F169"}});</script>
        <script>jQuery.LiveAddress("2709136500151817792");</script>
        <script>
            $(document).ready(function()
            {
                $('#btnLogin').on('click',function(e)
                {
                    e.preventDefault();
                    $.post("login.php", $("#login").serialize(),function(data) 
                    {
                        if (data == 0)
                        {
                            $('#response').html('Invalid Entry');
                            $('#response').fadeIn(600).fadeOut(600);
                        }
                        else
                        {
                            window.location.replace('./profile.php');
                        };
                    });   
                });
            });
        </script>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/dot-luv/jquery-ui.css"></link>
        <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
        <script>
            $(function()
            {
                $( "#dialog" ).dialog(
                {
                    autoOpen: false,
                    show: 
                    {
                        effect: "blind",
                        duration: 1000
                    },
                    hide: 
                    {
                        effect: "explode",
                        duration: 1000
                    }
                });

                $( "#opener" ).click(function() 
                {
                    $( "#dialog" ).dialog( "open" );
                });
            });
        </script>
        <script type="text/javascript" src="http://www.dynamicsitesolutions.com/library/js/contact.js"></script>
        <link href="style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <div id="container">
            <div id="leftcolumn">
            <div id="sitetitle">
                <div class="title">
                    Friend <span>Connect</span>
                </div>
            </div>
            <div id="menu">
                <ul>
                    <li><a href="profile.php">Main Page</a></li>
                    <li><a href="friends.php">Find Friends</a></li>
                </ul>
            </div>
            <?php
            session_start();
            include_once 'functions.php';
            if (!isset($_SESSION['loggedin']))
            {
                $_SESSION['loggedin']=FALSE;
            }
            if(!isset($_SESSION['user']))
            {
                echo"<div id='search'>
                    <div id='responce'></div>
                    <h2>Login</h2>
                    <form id='login' action='process_jquery.php' method='POST'>
                        <label><strong>Username</strong></label><input name='username' type='text' class='inputfield' maxlength='30'/>
                        <label><strong>Password</strong></label><input name='password' type='password' class='inputfield' maxlength='30'/>
                        <input class='button' id='btnLogin' type='submit' name='login' value='Login' />
                    </form>";
            } else {
                $row=get_user_info($_SESSION[user]);
                echo "<div id='search'>
                <h2> $row[fname] $row[lname] is Logged in.</h2>";
            }
            ?>
                    </div>
            </div>
            <div id="rightcolumn">
