<?php
include_once 'header.php';
?>
    <div id='left'>

        <iframe width="310" height="310" src="//www.youtube.com/embed/PtH4IFJhi38?rel=0&autoplay=1" frameborder="0" allowfullscreen></iframe>
        
    </div>
    <div id="right">
        
        <h1>Jonathon Night and Veronica Day Wedding</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer euismod, risus eget pretium facilisis, mauris nisl faucibus purus, at commodo nisi tellus sit amet ligula. Donec posuere purus vel lorem pellentesque, vitae fermentum lorem adipiscing. Vivamus nec nunc velit. Pellentesque turpis enim, porttitor nec facilisis in, tincidunt iaculis urna. Vestibulum porta quis ante vel luctus. Donec fermentum, nibh eget malesuada pulvinar, orci diam lobortis magna, sed fringilla erat risus et neque. Aenean suscipit, quam vitae cursus feugiat, massa sapien mattis nisi, et pretium mauris dui vitae nulla. Duis in lorem non libero tristique porttitor eu eget sem. Donec luctus ut libero vel volutpat.<br /><br />

Donec justo velit, pharetra et rutrum ac, ultricies sed dolor. Vivamus odio augue, commodo quis tempus ac, scelerisque sit amet sapien. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel lorem sed diam semper bibendum. Nunc iaculis tortor vitae leo malesuada, ac tincidunt nunc laoreet. Vestibulum elementum sem aliquet tortor euismod luctus. Integer et sollicitudin libero, eu venenatis sem.</p>
        <!-- <div id="pay"> -->
        <!-- <ul> -->
       <a href="pay.php"><div class="button">$25</div></a>
       <a href="pay.php"><div class="button">$50</div></a>
       <a href="pay.php"><div class="button">$75</div></a>
       <a href="pay.php"><div class="button">Custom</div></a>

        <!-- </ul> -->
        <!-- </div> -->
        
         
                    
    </div>
</div>
    
</body>