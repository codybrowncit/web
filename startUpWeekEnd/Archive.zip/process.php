<?php
include_once 'header.php';
?>
    <div id='left'>
        <img src='images/couple.jpg' alt='wedding photo' width='300'></img>
        
    </div>
    <div id="right">
       <?php
            echo "Thank You $_POST[name], Your Gift has Been Received.";
            
            
       ?>
        
    </div>
</body>



