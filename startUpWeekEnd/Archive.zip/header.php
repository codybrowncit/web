<?php
	include "assets/global.php";
?>
  
       
        <div id="nav">   <a href="index.php"><img src="images/their-fund-logo.png" width="222" height="47" alt="Their Fund Logo" /></a>
<ul>
    					
                        
                        <li><a href="Give-Money">Give to a Fund</a></li>
                        <li><a href="Get-Money">Create a Fund</a></li>
                        <li><a href="How-it-works">How It Works</a></li>
                        <li><a href="index.php">Home</a></li>
                    </ul>
                </div>
        