<div id="logo"> <img src="images/logo.gif" alt="company logo" width="800" /> 
         
            </div>
            