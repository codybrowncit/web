<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	 <div id= "content">
             	<h1>About Us</h1>
                      <img src="images/carpets2.jpg" width="300px" align="left" class="floatright"  />
                <p >Our company was est. around the basis of a go green affect. Raised in the floor, covering business I have seen thousands of pounds of pad make its way to our landfills. After moving to St. George. I became familiar with the process that bailed the pad and sent it to be recycled. I was very intrigued and excited that somebody offer this service in this area. I had always known that pad came from recycled material, but did not fully understand the process. I opened a retail carpet store in about 2006 after operating my own retail facility. I had become more familiar with the process. As the economy slowed my passion to find something else blossomed and I discovered new technologies and developed a passion for helping our planet. The company that processed this pad in our area had discontinued the collection due to out-of-town work. Because of this I have decided to take on a new project, and with the help of the citizens, the city the contractors and the carpet installers in our area. I plan on developing a system that will benefit our planet. I have named this company CPR, which stands for carpet pad recycling our tagline is resuscitating the planet. This material in our landfills is much like the clogging of arteries it does not biodegrade and inhibits the bio degrading process of other materials. So by detouring pad from the landfill. We are truly resuscitating our planet! Thank you for all of your help in doing so, we are only a phone call away and will service our planet, whenever you call.</p>
           
                
             </div>


<?php include("footer.php"); ?>