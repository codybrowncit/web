		<div id="footer">
            Copyright &copy; 2011 cpadrecycling.com<br/>
        </div>

	</div>   
     
</body>
</html>
