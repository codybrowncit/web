  <div id= "nav">
                    <div id="menu">
                    
                    <a href="index.php">Home</a>
                    <a href="mission.php">Our Mission</a>  
                    <a href="services.php">Services</a> 					
                    <a href="videoarchive.php">Video Archive</a>
                    <a href="aboutus.php">About Us</a>  
                    <a href="contacts.php">Contact Us</a>
                   
                    </div>
                </div>