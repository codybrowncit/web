<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	  <div id= "content">
  <img src="images/tags.gif" width="300px" align="left" class="floatright"  />
   <h1 class="floatleft">
   <br/>Benefits</h1>
     <br/>
     <br/>
     <br/>
     <br/>
     
          
           <ul>
    				<li>Helps the
environment</li><br/>
                    <li>Save your company
money by reducing
frequent dumping</li><br/>
                    <li>All recyclables
should be recycled</li><br/>
                    <li>Reduce reuse
recycle</li><br/>
                    <li>Convenient drop
off location</li><br/>
					<li>Saves you a trip to
the dump</li><br/>
               </ul>
               
       	 	</div>
           
         
           
       
      

<?php include("footer.php"); ?>
 
