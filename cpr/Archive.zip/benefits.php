<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	 <div id= "content">
             	<h1>Benefits</h1>
                
                <img src="images/carpets.jpg" width="250px" align="right"  class="floatright"  />
                
 				<ul>
    				<li>Helps the
environment</li><br/>
                    <li>Save your company
$ by reducing
frequent dumping</li><br/>
                    <li>All recyclables
should be recycled</li><br/>
                    <li>Reduce reuse
recycle</li><br/>
                    <li>Convenient drop
off location</li><br/>
					<li>Saves you a trip to
the dump</li><br/>
               </ul>
       	 	</div>
            
           


<?php include("footer.php"); ?>