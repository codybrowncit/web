<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	 <div id= "content">
             	<h1>Services</h1>
                
                <img src="images/truck.jpg" width="250px" align="right"  class="floatright"  />
                <div class="textcol">
 				<p>Our only product at CPR is our service . Our service is collecting your used flooring, helping to improve the quality of life on our planet and also saving the contractor and the retailer money. Filling your dumpsters less and also filling our landfills less. Anything that can be processed by recycling should be recycled. Help us by gathering this material before it makes its way to the landfill.</p>

<p>CPR offers a carpet and pad removal service, which is<br/> competitively priced and offered only to aid in the gathering of this material that can be recycled. We also have a pickup service that we provide. By placing a phone call we will send a truck and a trailer promptly to your home or place of business to retrieve your used carpet and pad. We will provide a central drop-off location with convenient access for your truck or trailer. For contractors and homeowners, there will be a 24-hour drop-off location. We ask that you help keep our location clean and free of all medals razor blades tack strip and nails. With your cooperation, we will provide a unique and versatile service.</p>
				</div>


    				
       	 	</div>


<?php include("footer.php"); ?>