<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	 <div id= "content">
             	<h1 align="center">Videos</h1>
           <center><iframe title="YouTube video player" width="480" height="390" src="http://www.youtube.com/embed/FgEWht1MfUA" frameborder="0" allowfullscreen ></iframe></center>
             </div>
             
             
                
                
<?php include("footer.php"); ?>                