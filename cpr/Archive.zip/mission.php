<?php include("header.php"); ?>

<body>
        <div id= "wrapper">
           <?php include ("logo.php"); ?>
           <?php include("menu.php"); ?>
		
        	 <div id= "content">
             	<h1>Our Mission</h1>
                 <img src="images/carpets.jpg" width="300px" align="left" class="floatright"  />
                <p>Our mission is to collect everything that we can so that it does not make its way to our landfills. Everything that can be recycled should be recycled. Reduce, reuse and recycle with these three objectives in mind. Our mission is to complete the circuit on a recycled basis. When we create awareness in our communities of the materials that can be recycled. We will be able to detour almost 100% of the material that can be recycled. With the help of our community from a home to home basis. We will work diligently with the contractors in our community to provide fast, friendly and efficient service. We thank all of you for your contributions, and offer any help we can in the collection of your used flooring. Let us help make this a better planet for the next generations, when we show them how to thrive, then they will.</p>


       	 	</div>


<?php include("footer.php"); ?>